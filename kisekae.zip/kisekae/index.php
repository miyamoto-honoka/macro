<?php



		header('location: 1001.php');