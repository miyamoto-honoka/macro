
var searchCondJob = [];
var searchCondElement = [];
	
	/**
	 * Ready
	 */
    $(function(){

	    
		
    	
        $(document).on( 'click', '#regButton', function() {
        	addTask( $('#task-input').val(), 1 );
        	
        });
    	
    	
    	
    	
	    //#=== クリックイベント ===#
    	//属性クリック
        $(document).on( 'click', 'button.btn-square-pop', function() {
	    	//詳細情報の読み込み
        	loadPhases();
        });

        /*
        
        
	    // タグボタンクリック時の動作
        $(document).on( 'click', '.condBtn', function(){
        	var tag_id = $(this).children('input').val();
        	if ($(this).hasClass('condOn') ) {
        		//条件の先頭に追加
            	if ($(this).hasClass('job') ) {
            		searchCondJob.unshift(tag_id);
            	} else {
            		searchCondElement.unshift(tag_id);
            	}
        	}else{
        		//条件から削除
            	if ($(this).hasClass('job') ) {
            		var condlist = searchCondJob;
            	} else {
            		var condlist = searchCondElement;
            	}
        		//配列をループして値を照合して要素を削除
        		for(i=0; i<condlist.length; i++){
        		    if(condlist[i] == tag_id){
        		    	condlist.splice(i, 1);
        		        break;
        		    }
        		}
            	if ($(this).hasClass('job') ) {
            		searchCondJob = condlist;
            	} else {
            		searchCondElement = condlist;
            	}
        	}
        	$(this).toggleClass("condOn");
        	console.log(searchCondJob)
        	console.log(searchCondElement)
        	
        	searchChara()
        });
        
        */

    });




	//#############################################################
	//             検　索
	//#############################################################
    /**
     * フェーズヘッダーのロード
     */
	function loadPhases() {
		//$('#conds').empty();

		$.ajax({
            type : "post",
			url: 'ajax/ajax_LoadPhases.php'
		})
        .then(
    		function(data) {
				if (data != '') {
					
					alert(data);
					
				} else {
				}
			},
			function() {
			}
        );
	}
	
	

	//#############################################################
	//             登　録
	//#############################################################

   /**
     * タスクデータの登録
     */
	function saveTask(ts_id, us_id, ph_id) {
	    $.ajax({
            type : "post",
	        url: 'ajax/ajax_SaveTasks.php',
            data:{
                'ts_id': ts_id,
                'us_id': us_id,
                'ph_id': ph_id
            }
	    })
        .then(
    		function(data) {
				toastr.success("登録完了");
			},
			function() {
				toastr.error("登録に失敗しました。");
			}
        );
	}
	   /**
     * タスクデータの新規作成
     */
	function addTask(task_str, us_id) {
		if (task_str == "") return;
		
	    $.ajax({
            type : "post",
	        url: 'ajax/ajax_AddTasks.php',
            data:{
                'task_str': task_str,
                'us_id': us_id
            }
	    })
        .then(
    		function(data) {
				toastr.success("登録完了");
				//ユーザーストーリーから再読み込み
				loadUserStorys();
			},
			function() {
				toastr.error("登録に失敗しました。");
			}
        );
	}


	
	
	
	
	
	
	
	
	
	
	
	

	//#############################################################
	//             画像登録
	//#############################################################
   /**
     * 画像登録
     */
	function registerProfileImage() {
		var formData = new FormData($('#imgform').get(0));
		formData.append("chara_id", $('#chara_id').val() );

		$.ajax({
            type : "post",
            url: 'ajax/Ajax1220_RegisterProfileImage.php',
            data: formData,
	        cache       : false,
	        contentType : false,
	        processData : false,
	        dataType    : "html"

		})
        .then(
    		function(data) {
				if (data != '') {
					$('#profImg').attr("src", "../profimg/"+data);
					toastr.success("画像登録完了");
				} else {
					toastr.info("失敗しました。");
				}
			},
			function() {
				toastr.error("登録に失敗しました。");
			}
        );
	}


