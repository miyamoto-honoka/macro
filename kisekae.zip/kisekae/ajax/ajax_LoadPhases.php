<?php
$str = "";
try {
    
    $image = file_get_contents('/path/to/sample.png');
    
    //ファイル出力
    /*
    $fileName = "file.txt";
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename='.$fileName);
    echo $image;
    */
    
	
	$str .= "<div class='task-board-col'>"."aaaaaaaa"."</div>";
	

}catch(Exception $e){

}
echo $str;

exit;
