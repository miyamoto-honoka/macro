<?php
$str = "";
try {
    
    error_log(print_r($_POST, true)."\n", 3, 'D:\errorlog.log');
    
    $item_id   = filter_input(INPUT_POST, "item_id");
    $colorNum  = filter_input(INPUT_POST, "colorNum");
    $colorName = filter_input(INPUT_POST, "colorName");
    $bijouSelect = filter_input(INPUT_POST, "check", FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
    
    error_log(print_r($bijouSelect, true)."\n", 3, 'D:\errorlog.log');
    
    //テンプレートの読み込み
    $temp = file_get_contents('../template/template_custom.html');
    
    
    //商品ID
    $temp = str_replace("■商品ID■", $item_id, $temp);
    
    //ベルト色パターン
    $colorNum = explode("\n", str_replace(array("\r\n", "\r", "\n"), "\n", $colorNum) );
    $colorName = explode("\n", str_replace(array("\r\n", "\r", "\n"), "\n", $colorName) );
    
    $str="";
    for($i=0; $i<count($colorNum); $i++){
        if (empty($colorName[$i]) ) {break;}
        $no   = sprintf('%02d', $i);
        $num  = sprintf('%03d', $colorNum[$i]);
        $name = $colorName[$i];
        
        $str .= "<li class=\"belt belt".$no."\"> <a href=\"javascript:void(0);\" class=\"belt".$no."\" name=\"".$item_id."_belt_".$num."\" id=\"".$item_id."_chip_".$num.".png\" title=\"".$name."(".$num.")\"> </a> <span class=\"colortext\">".$num."</span> </li>\n";
    }
    error_log(print_r($str, true)."\n", 3, 'D:\errorlog.log');
    $temp = str_replace("■ベルト色パターン■", $str, $temp);
    
    
    //尾錠色パターン
    
    $bijouNameS = array("silver","gold","black","rose");
    $bijouNameL = array("Silver","Gold","Black","RoseGold");
    
    $str="";
    for($i=0; $i<count($bijouSelect); $i++){
        
        $no   = sprintf('%02d', $bijouSelect[$i]);
        $str .="<li class=\"bijou bijou".$no."\"><a href=\"javascript:void(0);\" class=\"bijou".$no."\" name=\"c_bijou1_".$bijouNameS[$i].".png\"></a> <span class=\"colortext\">".$bijouNameL[$i]."</span> </li>\n";
    }
    error_log(print_r($str, true)."\n", 3, 'D:\errorlog.log');
    $temp = str_replace("■尾錠色パターン■", $str, $temp);
    
    
    //時計パターン
    /*
    if($isAPO) {
        
        
    } else {
        
        
        
    }*/
    
    
    
    
    
    
    //ファイル出力
    $fileName = $item_id."_custom.html";
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename='.$fileName);
    echo $temp;
    

}catch(Exception $e){

}

exit;
