<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
  
    <link href="https://fonts.googleapis.com/css?family=Poiret+One&display=swap" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
	
    <link rel="stylesheet" type="text/css" href="css/1001.css">

    <script type="text/javascript" src="js/1001.js"></script>
    
	<title>test</title>
</head>
<body>
	
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
        
        
			<form action ="ajax/act_OutputHTML.php" method = "POST">

                <div class="form-group">
                    <label for="text1">商品ID:</label>
                    <input type="text" name="item_id" class="form-control">
                </div>
                <div class="form-group">
                    <label for="text1">色:</label>
                    <div class="colorArea">
                        <textarea name="colorNum" class="form-control"></textarea>
                        <textarea name="colorName" class="form-control"></textarea>
                	</div>
                </div>
                
                
				<input type="checkbox"  name="check[]" value="1">
				<input type="checkbox"  name="check[]" value="2">
				<input type="checkbox"  name="check[]" value="3">
				<input type="checkbox"  name="check[]" value="4">
				
                
                <input type ="submit" class="btn-square-pop" value="送信">
            </form>
            
            
            <button type="button" class="btn-square-pop">保存</button>
            
        </div>
        <div class="col-md-8">
        a
    	</div>
        

    </div>
</div>


</body>
</html>