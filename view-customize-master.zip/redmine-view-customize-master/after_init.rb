require_dependency 'view_customize/view_hook'
